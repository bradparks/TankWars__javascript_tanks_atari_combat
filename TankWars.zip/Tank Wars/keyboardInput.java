import java.awt.event.KeyEvent;
import java.awt.Toolkit;

public class keyboardInput {
	
	public keyboardInput() {
	}
	
	public String getCharacter(int keyCode, boolean shift) {
		
		boolean upperCase = shift;
		boolean capsLock = false;
		 
		try { 
		   capsLock = Toolkit.getDefaultToolkit().getLockingKeyState(KeyEvent.VK_CAPS_LOCK); 
		} 
		catch (Exception e) { 
		} 
		
		String st = ""; 
		
		switch (keyCode) { 
		   case KeyEvent.VK_BACK_QUOTE: st = (upperCase) ? "~" : "`"; break; 
		   case KeyEvent.VK_1:    st = (upperCase) ? "!" : "1"; break; 
		   case KeyEvent.VK_2:    st = (upperCase) ? "@" : "2"; break; 
		   case KeyEvent.VK_3:    st = (upperCase) ? "#" : "3"; break; 
		   case KeyEvent.VK_4:    st = (upperCase) ? "$" : "4"; break; 
		   case KeyEvent.VK_5:    st = (upperCase) ? "%" : "5"; break; 
		   case KeyEvent.VK_6:    st = (upperCase) ? "^" : "6"; break; 
		   case KeyEvent.VK_7:    st = (upperCase) ? "&" : "7"; break; 
		   case KeyEvent.VK_8:    st = (upperCase) ? "*" : "8"; break; 
		   case KeyEvent.VK_9:    st = (upperCase) ? "(" : "9"; break; 
		   case KeyEvent.VK_0:    st = (upperCase) ? ")" : "0"; break; 
		   case KeyEvent.VK_MINUS: st = (upperCase) ? "_" : "-"; break; 
		   case KeyEvent.VK_EQUALS: st = (upperCase) ? "+" : "="; break; 
		   case KeyEvent.VK_BACK_SLASH: st = (upperCase) ? "|" : "\\"; break; 
		   case KeyEvent.VK_OPEN_BRACKET: st = (upperCase) ? "{" : "["; break; 
		   case KeyEvent.VK_CLOSE_BRACKET: st = (upperCase) ? "}" : "]"; break; 
		   case KeyEvent.VK_SEMICOLON: st = (upperCase) ? ":" : ";"; break; 
		   case KeyEvent.VK_QUOTE:   st = (upperCase) ? "\"" : "'"; break; 
		   case KeyEvent.VK_COMMA:   st = (upperCase) ? "<" : ","; break; 
		   case KeyEvent.VK_PERIOD: st = (upperCase) ? ">" : "."; break; 
		   case KeyEvent.VK_SLASH: st = (upperCase) ? "?" : "/"; break; 
		   case KeyEvent.VK_DIVIDE: st = "/"; break; 
		   case KeyEvent.VK_MULTIPLY: st = "*"; break; 
		   case KeyEvent.VK_SUBTRACT: st = "-"; break; 
		   case KeyEvent.VK_ADD: st = "+"; break; 
		   case KeyEvent.VK_DECIMAL: st = "."; break; 
		   case KeyEvent.VK_SPACE: st = " "; break; 
		   default: 
		      st = KeyEvent.getKeyText(keyCode).toLowerCase(); 
		      if (st.startsWith("numpad")) { 
		         // convert numpadX -> X 
		         st = st.substring(7); 
		      } 
		
		      if (st.length() == 0 || st.length() > 1) { 
		         // invalid key 
		         return ""; 
		      } 
		   break; 
		} 
		
		if (keyCode >= KeyEvent.VK_A && keyCode <= KeyEvent.VK_Z) { 
		   if (upperCase && !capsLock || !upperCase && capsLock) { 
		      // upper case 
		      st = st.toUpperCase(); 
		   } 
		} 
		
		if (st == "") return ""; 
		
		return st;
	}
	
}