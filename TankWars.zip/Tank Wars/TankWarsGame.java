import java.awt.event.KeyEvent;
import java.awt.Graphics2D;
import java.awt.Color;
import java.awt.Font;

import javax.swing.JOptionPane;

import com.golden.gamedev.object.collision.CollisionGroup;
import com.golden.gamedev.object.background.ColorBackground;
import com.golden.gamedev.object.Background;
import com.golden.gamedev.object.collision.CollisionBounds;
import com.golden.gamedev.object.font.SystemFont;
import com.golden.gamedev.object.SpriteGroup;
import com.golden.gamedev.object.PlayField;
import com.golden.gamedev.object.Sprite;
import com.golden.gamedev.util.FileUtil;
import com.golden.gamedev.util.ImageUtil;
import com.golden.gamedev.GameObject;
import com.golden.gamedev.GameEngine;

import com.golden.gamedev.object.Timer;

public class TankWarsGame extends GameObject {

	PlayField	field;

	SpriteGroup	WALLS;
	SpriteGroup	TANKS;
	SpriteGroup	TURRETS;
	SpriteGroup	PROJECTILES1;
	SpriteGroup	PROJECTILES2;
	SpriteGroup	FLOOR;

	TankSprite		tank1;
	TurretSprite	turret1;
	TankSprite		tank2;
	TurretSprite	turret2;

	SystemFont	font;

	int			player1Lives;
	int			player2Lives;

	Timer		fire1;
	Timer		fire2;

	boolean		ready1;
	boolean		ready2;

	public TankWarsGame(GameEngine parent) {

		super(parent);

	}

	public TankWarsEngine getEngine() {

    	return (TankWarsEngine) parent;

    }

	public double middle(double num, int size) {

   		return num - size/2;

   	}

   	public void loadLevel() {
   		GameObject input = new MapSelector(parent); 
		input.start();
   		
   		String[] mapInfo = FileUtil.fileRead(bsIO.getStream(getEngine().input));

   		int height	= Integer.parseInt(mapInfo[0]);
   		int width	= Integer.parseInt(mapInfo[1]);



   		for(int count = 0; count < height; count++) {
   			for(int count2 = 0; count2 < width; count2++) {
   				if(mapInfo[count+2].charAt(count2) == '0') {
   					setMaskColor(Color.white);
   					Sprite floor	= new Sprite(getImage("images\\concretev3.PNG"),count*32,count2*32);
			   		FLOOR.add(floor);
   				}
   				if(mapInfo[count+2].charAt(count2) == '1') {
   					setMaskColor(Color.white);
   					Sprite wall	= new Sprite(getImage("images\\wallv3.PNG"),count*32,count2*32);
			   		WALLS.add(wall);
   				}
   				if(mapInfo[count+2].charAt(count2) == '2') {
   					setMaskColor(Color.white);
   					tank1	= new TankSprite(getImage("images\\tank1v3.PNG"));
			   		tank1.setLocation(middle(count*32+16, tank1.getWidth()),middle(count2*32+16, tank1.getHeight()));
			   		tank1.setAngle(180);
			   		TANKS.add(tank1);
			   		setMaskColor(Color.white);
   					Sprite floor	= new Sprite(getImage("images\\concretev3.PNG"),count*32,count2*32);
			   		FLOOR.add(floor);
   				}
   				if(mapInfo[count+2].charAt(count2) == '3') {
   					setMaskColor(Color.white);
   					tank2	= new TankSprite(getImage("images\\tank2v3.GIF"));
			   		tank2.setLocation(middle(count*32+16, tank2.getWidth()),middle(count2*32+16, tank2.getHeight()));
			   		tank2.setAngle(0);
			   		TANKS.add(tank2);
			   		setMaskColor(Color.white);
   					Sprite floor	= new Sprite(getImage("images\\concretev3.PNG"),count*32,count2*32);
			   		FLOOR.add(floor);
   				}
   			}
   		}

   	}

   	public void initResources() {

   		hideCursor();

   		player1Lives	= 3;
   		player2Lives	= 3;

   		ready1	= false;
   		ready2	= false;

   		fire1	= new Timer(3000);
   		fire2	= new Timer(3000);

   		font		= new SystemFont(new Font("Impact",Font.PLAIN,25), Color.red);

   		field			= new PlayField(new ColorBackground(Color.black));
   		WALLS			= field.addGroup(new SpriteGroup("WALLS"));
   		FLOOR			= field.addGroup(new SpriteGroup("FLOOR"));
   		PROJECTILES1	= field.addGroup(new SpriteGroup("PROJECTILES1"));
   		PROJECTILES2	= field.addGroup(new SpriteGroup("PROJECTILES2"));
   		TANKS			= field.addGroup(new SpriteGroup("TANKS"));
   		TURRETS			= field.addGroup(new SpriteGroup("TURRETS"));

		loadLevel();

		setMaskColor(Color.white);
   		turret1	= new TurretSprite(getImage("images\\turret1v3.PNG"),tank1);
   		turret1.setLocation(middle(tank1.getX()+tank1.getWidth()/2,turret1.getWidth()),middle(tank1.getY()+tank1.getHeight()/2,turret1.getHeight()));
   		turret1.setAngle(180);
   		TURRETS.add(turret1);
   		turret2	= new TurretSprite(getImage("images\\turret2v3.PNG"),tank2);
   		turret2.setLocation(middle(tank2.getX()+tank2.getWidth()/2,turret2.getWidth()),middle(tank2.getY()+tank2.getHeight()/2,turret2.getHeight()));
   		TURRETS.add(turret2);

   		field.addCollisionGroup(TANKS,WALLS,new TankWallCollision());
   		field.addCollisionGroup(PROJECTILES1,WALLS,new ProjectileWallCollision());
   		field.addCollisionGroup(PROJECTILES2,WALLS,new ProjectileWallCollision());
   		field.addCollisionGroup(TANKS,TANKS,new TankTankCollision());
   		field.addCollisionGroup(TANKS,PROJECTILES1,new TankProjectile1Collision());
   		field.addCollisionGroup(TANKS,PROJECTILES2,new TankProjectile2Collision());
   		field.addCollisionGroup(TANKS,null,new TankBackgroundCollision(field.getBackground()));
   		field.addCollisionGroup(PROJECTILES1,null,new ProjectileBackgroundCollision(field.getBackground()));
   		field.addCollisionGroup(PROJECTILES2,null,new ProjectileBackgroundCollision(field.getBackground()));
   	}

   	public void update(long e) {
   		field.update(e);

		if(player1Lives == 0 || player2Lives == 0) {
			finish();
		}

   		if (fire1.action(e)) {
   			ready1	= true;
   		}
   		if (fire2.action(e)) {
   			ready2	= true;
   		}

   		if(keyDown(KeyEvent.VK_A)) {
   			tank1.setAngle(tank1.angle-1);
   			turret1.setAngle(turret1.angle-1);
   		}
   		else if(keyDown(KeyEvent.VK_D)) {
   			tank1.setAngle(tank1.angle+1);
   			turret1.setAngle(turret1.angle+1);
   		}
   		if(keyDown(KeyEvent.VK_W)) {
   			tank1.setSpeed(.03);
   			turret1.setSpeed(.03);
   		}
   		else if(keyDown(KeyEvent.VK_S)) {
   			tank1.setSpeed(-.03);
   			turret1.setSpeed(-.03);
   		}
   		else {
   			tank1.setSpeed(0);
   			turret1.setSpeed(0);
   		}

   		if(keyDown(KeyEvent.VK_F)) {
   			turret1.setAngle(turret1.angle-1);
   		}
   		else if(keyDown(KeyEvent.VK_G)) {
   			turret1.setAngle(turret1.angle+1);
   		}

   		if(keyDown(KeyEvent.VK_SPACE)&&ready1) {
   			Sprite projectile	= new Sprite(ImageUtil.rotate(getImage("images\\shell.PNG"),turret1.angle));
   			double middlex	= middle((tank1.getWidth()/2)+tank1.getX(),projectile.getWidth());
   			double middley = middle((tank1.getHeight()/2)+tank1.getY(),projectile.getHeight());
   			projectile.setLocation(middlex,middley);
   			projectile.setMovement(.2,turret1.angle);

   			PROJECTILES1.add(projectile);
   			fire1.setDelay(3000);
   			ready1	= false;
   		}

   		if(keyDown(KeyEvent.VK_LEFT)) {
   			tank2.setAngle(tank2.angle-1);
   			turret2.setAngle(turret2.angle-1);
   		}
   		else if(keyDown(KeyEvent.VK_RIGHT)) {
   			tank2.setAngle(tank2.angle+1);
   			turret2.setAngle(turret2.angle+1);
   		}
   		if(keyDown(KeyEvent.VK_UP)) {
   			tank2.setSpeed(.03);
   			turret2.setSpeed(.03);
   		}
   		else if(keyDown(KeyEvent.VK_DOWN)) {
   			tank2.setSpeed(-.03);
   			turret2.setSpeed(-.03);
   		}
   		else {
   			tank2.setSpeed(0);
   			turret2.setSpeed(0);
   		}

   		if(keyDown(KeyEvent.VK_NUMPAD4)) {
   			turret2.setAngle(turret2.angle-1);
   		}
   		else if(keyDown(KeyEvent.VK_NUMPAD5)) {
   			turret2.setAngle(turret2.angle+1);
   		}

   		if(keyDown(KeyEvent.VK_ENTER)&&ready2) {
   			Sprite projectile	= new Sprite(ImageUtil.rotate(getImage("images\\shell.PNG"),turret2.angle));
   			double middlex	= middle((tank2.getWidth()/2)+tank2.getX(),projectile.getWidth());
   			double middley = middle((tank2.getHeight()/2)+tank2.getY(),projectile.getHeight());
   			projectile.setLocation(middlex,middley);
   			projectile.setMovement(.2,turret2.angle);

   			PROJECTILES2.add(projectile);
   			fire2.setDelay(3000);
   			ready2	= false;
   		}

   		if(keyPressed(KeyEvent.VK_ESCAPE)) {
   			parent.nextGameID = getEngine().TITLE;
			finish();
		}
   	}

   	public void render(Graphics2D g) {
   		field.render(g);

   		font.drawString(g,"Player1's Hitpoints: " + player1Lives,5,0);
   		font.drawString(g,"Player2's Hitpoints: " + player2Lives,400,0);
   	}

   	class TankWallCollision extends CollisionGroup {

   		public TankWallCollision() {
			pixelPerfectCollision = true;
   		}

   		public void collided(Sprite s1, Sprite s2) {
   			if(collisionSide == TOP_BOTTOM_COLLISION) {
   				s1.setY(s2.getY()+s2.getHeight());
   			}
   			else if(collisionSide == LEFT_RIGHT_COLLISION) {
   				s1.setX(s2.getX()+s2.getWidth());
   			}
   			else if(collisionSide == BOTTOM_TOP_COLLISION) {
   				s1.setY(s2.getY()-s1.getHeight());
   			}
   			else if(collisionSide == RIGHT_LEFT_COLLISION) {
   				s1.setX(s2.getX()-s1.getWidth());
   			}

   			if(s1.equals(tank1)) {
   				turret1.setLocation(middle(tank1.getX()+tank1.getWidth()/2,turret1.getWidth()),middle(tank1.getY()+tank1.getHeight()/2,turret1.getHeight()));
   			}
   			else if(s1.equals(tank2)) {
   				turret2.setLocation(middle(tank2.getX()+tank2.getWidth()/2,turret2.getWidth()),middle(tank2.getY()+tank2.getHeight()/2,turret2.getHeight()));
   			}
   		}

   	}

   	class ProjectileWallCollision extends CollisionGroup {

   		public ProjectileWallCollision() {

   		}

   		public void collided(Sprite s1, Sprite s2) {
   			s1.setActive(false);
   		}

   	}

   	class TankTankCollision extends CollisionGroup {

   		public TankTankCollision() {
   			pixelPerfectCollision = true;
   		}

   		public void collided(Sprite s1, Sprite s2) {
   			if(collisionSide == TOP_BOTTOM_COLLISION) {
   				s1.setY(s1.getY()+1);
   				s2.setY(s2.getY()-1);
   			}
   			else if(collisionSide == LEFT_RIGHT_COLLISION) {
   				s1.setX(s1.getX()+1);
   				s2.setX(s2.getX()-1);
   			}
   			else if(collisionSide == BOTTOM_TOP_COLLISION) {
   				s1.setY(s1.getY()-1);
   				s2.setY(s2.getY()+1);
   			}
   			else if(collisionSide == RIGHT_LEFT_COLLISION) {
   				s1.setX(s1.getX()-1);
   				s2.setX(s2.getX()+1);
   			}

   			turret1.setLocation(middle(tank1.getX()+tank1.getWidth()/2,turret1.getWidth()),middle(tank1.getY()+tank1.getHeight()/2,turret1.getHeight()));
   			turret2.setLocation(middle(tank2.getX()+tank2.getWidth()/2,turret2.getWidth()),middle(tank2.getY()+tank2.getHeight()/2,turret2.getHeight()));
   		}

   	}

   	class TankProjectile1Collision extends CollisionGroup {

   		public TankProjectile1Collision() {
   			pixelPerfectCollision = true;
   		}

   		public void collided(Sprite s1, Sprite s2) {
   			if(s1.equals(tank2)) {

	   			s2.setActive(false);
	   			player2Lives--;
   			}
   		}

   	}

   	class TankProjectile2Collision extends CollisionGroup {

   		public TankProjectile2Collision() {
   			pixelPerfectCollision = true;
   		}

   		public void collided(Sprite s1, Sprite s2) {
   			if(s1.equals(tank1)) {

	   			s2.setActive(false);
	   			player1Lives--;
   			}
   		}

   	}

   	class TankBackgroundCollision extends CollisionBounds {

   		TankBackgroundCollision(Background background) {
   			super(background);
   		}

   		public void collided(Sprite s) {
   		}

   	}

   	class ProjectileBackgroundCollision extends CollisionBounds {

   		ProjectileBackgroundCollision(Background background) {
   			super(background);
   		}

   		public void collided(Sprite s) {
   			s.setActive(false);
   		}

   	}

}