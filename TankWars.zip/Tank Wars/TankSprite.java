import java.awt.Graphics2D;
import java.awt.image.BufferedImage;

import com.golden.gamedev.object.Sprite;
import com.golden.gamedev.util.ImageUtil;

public class TankSprite extends Sprite {

	int angle;
	double speed;
	BufferedImage original;

	public TankSprite(BufferedImage image) {
		super(image);
		original	= image;
	}

	public void setAngle(int angle) {
		this.angle	= angle;
		setImage(ImageUtil.rotate(original, angle));
		calcSpeed();
	}

	public void setSpeed(double speed) {
		this.speed	= speed;
		calcSpeed();
	}

	public void calcSpeed() {
		setMovement(speed, angle);
	}

}