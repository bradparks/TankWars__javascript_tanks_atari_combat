import java.awt.event.KeyEvent;
import java.awt.Graphics2D;
import java.awt.Color;
import java.awt.Font;

import com.golden.gamedev.object.collision.PreciseCollisionGroup;
import com.golden.gamedev.object.background.ColorBackground;
import com.golden.gamedev.object.collision.CollisionBounds;
import com.golden.gamedev.object.font.SystemFont;
import com.golden.gamedev.object.SpriteGroup;
import com.golden.gamedev.object.PlayField;
import com.golden.gamedev.object.Sprite;
import com.golden.gamedev.GameObject;
import com.golden.gamedev.GameEngine;

public class TankWarsTitle extends GameObject {

	PlayField	field;

	SpriteGroup	MENU;

	Sprite	play;
	Sprite	editor;

	public TankWarsTitle(GameEngine parent) {

		super(parent);

	}

	public TankWarsEngine getEngine() {

    	return (TankWarsEngine) parent;

    }

	public void initResources() {
		showCursor();

		field	= new PlayField(new ColorBackground(Color.black));
		MENU	= field.addGroup(new SpriteGroup("MENU"));

		setMaskColor(Color.white);
		
		MENU.add(new Sprite(getImage("images\\tankTitlev3.PNG"),0, 0));
		MENU.add(new Sprite(getImage("images\\tankTitle2v3.PNG"),576-219, 0));
		
		MENU.add(new Sprite(getImage("images\\tankWarsTitlev3.PNG"), 576/2-387/2,180));
		
		play	= new Sprite(getImage("images\\playv3.PNG"));
		play.setLocation(230, 300);
		MENU.add(play);

		editor	= new Sprite(getImage("images\\editorv3.PNG"));
		editor.setLocation(230,370);
		MENU.add(editor);
	}

	public void update(long e) {

		if(click()) {
			if(checkPosMouse(play, false)) {
				parent.nextGameID = getEngine().GAME;
        		finish();
			}
			if(checkPosMouse(editor, false)) {
				parent.nextGameID = getEngine().MAPEDITOR;
        		finish();
			}
		}
		if(keyPressed(KeyEvent.VK_ESCAPE)) {
			finish();
		}

	}

	public void render(Graphics2D g) {
		field.render(g);
	}

}