import com.golden.gamedev.GameLoader;
import com.golden.gamedev.Game;

public class TankWarsApplet extends GameLoader {

    protected Game createAppletGame() {
        return new TankWarsEngine();
    }

}
