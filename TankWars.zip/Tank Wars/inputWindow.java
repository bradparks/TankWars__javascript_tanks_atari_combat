import java.awt.event.KeyEvent;
import java.awt.Graphics2D;
import java.awt.Color;
import java.awt.Font;

import com.golden.gamedev.object.collision.CollisionGroup;
import com.golden.gamedev.object.background.ColorBackground;
import com.golden.gamedev.object.Background;
import com.golden.gamedev.object.collision.CollisionBounds;
import com.golden.gamedev.object.font.SystemFont;
import com.golden.gamedev.object.SpriteGroup;
import com.golden.gamedev.object.PlayField;
import com.golden.gamedev.object.Sprite;
import com.golden.gamedev.util.FileUtil;
import com.golden.gamedev.util.ImageUtil;
import com.golden.gamedev.GameObject;
import com.golden.gamedev.GameEngine;

public class inputWindow extends GameObject {
	
	PlayField	field;
	
	SystemFont	font;
	
	String		message;
	String		input;
	
	public inputWindow(GameEngine parent, String message) {
		super(parent);
		this.message	= message;
	}
	
	public TankWarsEngine getEngine() {

    	return (TankWarsEngine) parent;

    }
	
	public void initResources() {
		field	= new PlayField(new ColorBackground(Color.lightGray));
		
		font	= new SystemFont(new Font("Impact",Font.PLAIN,25), Color.red);
		
		input	= "";
	}
	
	public void update(long e) {
		
		keyboardInput	converter	= new keyboardInput();
		
		if(bsInput.getKeyPressed()!=bsInput.NO_KEY) {
			if(keyPressed(KeyEvent.VK_ENTER)) {
				getEngine().input	= input;
				finish();
			}
			else if(keyPressed(KeyEvent.VK_BACK_SPACE)) {
				if(input.length()>0) {
					input	= input.substring(0,input.length()-1);
				}
			}
			else {
				input	+= converter.getCharacter(bsInput.getKeyPressed(),keyPressed(KeyEvent.VK_SHIFT));
			}
		}
		
	}
	
	public void render(Graphics2D g) {
		field.render(g);
		
		font.drawString(g, message, 0,0);
		font.drawString(g, input, message.length()*12+30, 0);
	}
	
}