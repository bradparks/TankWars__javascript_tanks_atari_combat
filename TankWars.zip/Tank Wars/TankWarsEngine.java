import com.golden.gamedev.GameEngine;
import com.golden.gamedev.GameObject;
import com.golden.gamedev.GameLoader;

import java.awt.Dimension;

public class TankWarsEngine extends GameEngine {

	public static final int GAME			= 0;
	public static final int TITLE			= 1;
	public static final int INSTRUCTIONS	= 2;
	public static final int MAPEDITOR		= 3;
	public static final int INPUT			= 4;
	public static final int SELECTOR		= 5;

	public String	input;

	public void initResources() {

		nextGameID	= 1;

	}

	public GameObject getGame(int gameID) {
		switch(gameID) {

			case GAME:
				nextGame = new TankWarsGame(this);
				break;
			case TITLE:
				nextGame = new TankWarsTitle(this);
				break;
			case INSTRUCTIONS:
				nextGame = new TankWarsInstruc(this);
				break;
			case MAPEDITOR:
				nextGame = new MapEditor(this);
				break;
			case SELECTOR:
				nextGame = new MapSelector(this);
				break;
		}
		return nextGame;
	}

	public static void main(String args[]) {
		GameLoader game = new GameLoader();
		game.setup(new TankWarsEngine(), new Dimension(576, 576), false);
		game.start();

	}

}