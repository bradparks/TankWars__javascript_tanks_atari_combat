import java.awt.event.KeyEvent;
import java.awt.Graphics2D;
import java.awt.Color;
import java.awt.Font;

import javax.swing.JOptionPane;

import java.io.File;

import com.golden.gamedev.object.collision.CollisionGroup;
import com.golden.gamedev.object.background.ColorBackground;
import com.golden.gamedev.object.Background;
import com.golden.gamedev.object.collision.CollisionBounds;
import com.golden.gamedev.object.font.SystemFont;
import com.golden.gamedev.object.SpriteGroup;
import com.golden.gamedev.object.PlayField;
import com.golden.gamedev.object.Sprite;
import com.golden.gamedev.util.FileUtil;
import com.golden.gamedev.util.ImageUtil;
import com.golden.gamedev.GameObject;
import com.golden.gamedev.GameEngine;

public class MapEditor extends GameObject {

	PlayField	field;

	SpriteGroup	WALLS;
	SpriteGroup	TANKS;
	
	boolean 	tank1=false;
	boolean 	tank2=false;

	int[][]		map;

	public MapEditor(GameEngine parent) {
		super(parent);
	}

	public TankWarsEngine getEngine() {

    	return (TankWarsEngine) parent;

    }

	public double middle(double num, int size) {

   		return num - size/2;

   	}

	public void initResources() {

		field	= new PlayField(new ColorBackground(Color.lightGray));
		WALLS	= field.addGroup(new SpriteGroup("WALLS"));
		TANKS	= field.addGroup(new SpriteGroup("TANKS"));
		
		GameObject input = new inputWindow(parent, "Tile width of map?"); 
		input.start();
		String width	= getEngine().input;
		
		input = new inputWindow(parent, "Tile Height of map?"); 
		input.start();
		
		map	= new int[Integer.parseInt(width)][Integer.parseInt(getEngine().input)];

		field	= new PlayField(new ColorBackground(Color.lightGray,32*map.length,32*map[0].length));
		WALLS	= field.addGroup(new SpriteGroup("WALLS"));
		TANKS	= field.addGroup(new SpriteGroup("TANKS"));

		for(int count = 1; count < map.length-1; count++) {
			for(int count2 = 1; count2 < map[0].length-1; count2++) {
				map[count][count2] = 0;
			}
		}
		for(int count = 0; count < map[0].length; count++) {
			map[0][count] = 1;
			Sprite wall	= new Sprite(getImage("images\\wall.PNG"));
			wall.setLocation(middle(0*32+16,wall.getWidth()),middle(count*32+16,wall.getHeight()));
			WALLS.add(wall);
		}
		for(int count = 0; count < map[0].length; count++) {
			map[map.length-1][count] = 1;
			Sprite wall	= new Sprite(getImage("images\\wall.PNG"));
			wall.setLocation(middle((map.length-1)*32+16,wall.getWidth()),middle(count*32+16,wall.getHeight()));
			WALLS.add(wall);
		}
		for(int count = 0; count < map.length; count++) {
			map[count][0] = 1;
			Sprite wall	= new Sprite(getImage("images\\wall.PNG"));
			wall.setLocation(middle(count*32+16,wall.getWidth()),middle(0*32+16,wall.getHeight()));
			WALLS.add(wall);
		}
		for(int count = 0; count < map.length; count++) {
			map[count][map.length-1] = 1;
			Sprite wall	= new Sprite(getImage("images\\wall.PNG"));
			wall.setLocation(middle(count*32+16,wall.getWidth()),middle((map.length-1)*32+16,wall.getHeight()));
			WALLS.add(wall);
		}

	}

	public void update(long e) {
		field.update(e);

		if(click()) {
			int x	= getMouseX();
			int y	= getMouseY();

			x	= x	- (x % 32);
			y	= y	- (y % 32);
			if(x/32<map.length && y/32<map[0].length) {
			
				int type	= map[x/32][y/32];
	
				x	+= 16;
				y	+= 16;
	
				if(type == 0) {
					Sprite wall	= new Sprite(getImage("images\\wall.PNG"));
					wall.setLocation(middle(x,wall.getWidth()),middle(y,wall.getHeight()));
					WALLS.add(wall);
					map[(x-16)/32][(y-16)/32] = 1;
				}
				if(type == 1) {
					Sprite sprites[]	= WALLS.getSprites();
					for(int count = 0; count < sprites.length; count++) {
						if(checkPosMouse(sprites[count], false)) {
							WALLS.remove(count);
							count = sprites.length;
						}
					}
						Sprite player1	= new Sprite(getImage("images\\tank1.GIF"));
						player1.setLocation(middle(x,player1.getWidth()),middle(y,player1.getHeight()));
						TANKS.add(player1);
						map[(x-16)/32][(y-16)/32] = 2;
				}
				if(type == 2) {
					Sprite sprites[]	= TANKS.getSprites();
					for(int count = 0; count < sprites.length; count++) {
						if(checkPosMouse(sprites[count], false)) {
							TANKS.remove(count);
							count = sprites.length;
						}
					}
						Sprite player2	= new Sprite(getImage("images\\tank2.GIF"));
						player2.setLocation(middle(x,player2.getWidth()),middle(y,player2.getHeight()));
						TANKS.add(player2);
						map[(x-16)/32][(y-16)/32] = 3;
				}
				if(type == 3) {
					Sprite sprites[]	= TANKS.getSprites();
					for(int count = 0; count < sprites.length; count++) {
						if(checkPosMouse(sprites[count], false)) {
							TANKS.remove(count);
							count = sprites.length;
						}
					}
					map[(x-16)/32][(y-16)/32] = 0;
				}
			}
		}

		if(keyPressed(KeyEvent.VK_ESCAPE)) {
   			parent.nextGameID = getEngine().TITLE;
			finish();
		}

		if(keyPressed(KeyEvent.VK_ENTER)) {
			save();
		}

	}

	public void save() {
		String string[] = new String[21];

		string[0] = "" + map.length;
		string[1] = "" + map[0].length;

		for(int count = 0; count < map.length; count++) {
			String line = "";
			for(int count2 = 0; count2 < map[0].length; count2++) {
				line += "" + map[count2][count];
			}
			string[count+2] = line;
		}
		
		GameObject input = new inputWindow(parent, "Map Name?"); 
		input.start();
		
		FileUtil.fileWrite(string, new File("maps/" + getEngine().input + ".twm"));
	}

	public void render(Graphics2D g) {
		field.render(g);
	}

}