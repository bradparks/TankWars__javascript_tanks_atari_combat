import java.awt.Graphics2D;
import java.awt.image.BufferedImage;

import com.golden.gamedev.object.Sprite;
import com.golden.gamedev.util.ImageUtil;

public class TurretSprite extends Sprite {

	int 			angle;
	double 			speed;
	BufferedImage 	original;
	TankSprite		tank;

	public TurretSprite(BufferedImage image, TankSprite tank) {
		super(image);
		original	= image;
		this.tank	= tank;
	}

	public void setAngle(int angle) {
		this.angle	= angle;
		setImage(ImageUtil.rotate(original, angle));
		calcSpeed();
	}

	public void setSpeed(double speed) {
		this.speed	= speed;
		calcSpeed();
	}

	public void calcSpeed() {
		setMovement(speed, tank.angle);
	}

}