import java.io.File;
import com.golden.gamedev.object.font.SystemFont;
import com.golden.gamedev.GameObject;
import com.golden.gamedev.GameEngine;
import java.awt.event.KeyEvent;
import java.awt.Graphics2D;
import java.awt.Color;
import java.awt.Font;
import java.io.FilenameFilter;
import com.golden.gamedev.object.background.ColorBackground;
import com.golden.gamedev.object.PlayField;

public class MapSelector extends GameObject {
	
	File mapList[];
	SystemFont	font;
	PlayField	field;
	
	int index;
	
	public MapSelector(GameEngine parent) {
		super(parent);
	}
	
	public TankWarsEngine getEngine() {

    	return (TankWarsEngine) parent;

    }
    
	public void initResources() {
		index	=	0;
		
		field	= new PlayField(new ColorBackground(Color.black));
		
		font	= new SystemFont(new Font("Impact",Font.PLAIN,25), Color.lightGray);
		
		File mainDirectory	= new File("maps/");
		mapList = mainDirectory.listFiles(new FilenameFilter(){ 
	         public boolean accept(File dir, String name) { 
	            return name.endsWith(".twm"); 
	         } 
		});
	}
	
	public void update(long e) {
		field.update(e);
		
		if(keyPressed(KeyEvent.VK_DOWN) && index != mapList.length-1) {
			index++;
		}
		else if(keyPressed(KeyEvent.VK_UP) && index != 0) {
			index--;
		}
		else if(keyPressed(KeyEvent.VK_ENTER)) {
			getEngine().input = mapList[index].getPath();
			finish();
		}
	}
	
	public void render(Graphics2D g) {
		field.render(g);
		g.setColor(Color.gray);
		g.fillRect(5,10+30*index,200,30);
		for(int count=0;count < mapList.length;count++) {
			font.drawText(g,mapList[count].getName().substring(0,mapList[count].getName().length()-4),font.LEFT,10,10+30*count,200,0,0);
		}
	}
	
}