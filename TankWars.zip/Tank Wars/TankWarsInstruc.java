import com.golden.gamedev.GameObject;
import com.golden.gamedev.GameEngine;
import java.awt.Graphics2D;

public class TankWarsInstruc extends GameObject {
	
	public TankWarsInstruc(GameEngine parent) {

		super(parent);

	}
	
	public void initResources() {
	}
	
	public void update(long e) {
	}
	
	public void render(Graphics2D g) {
	}
	
}